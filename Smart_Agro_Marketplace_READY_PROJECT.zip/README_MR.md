# Smart Agro Marketplace — Android Project

हा Android Studio साठी starter project आहे. App चे UI स्थानिक HTML/CSS/JavaScript मधून Android WebView मध्ये उघडते.

## फक्त mobile वापरून APK build (GitHub Actions)

1. ZIP फोनमध्ये डाउनलोड करून Files app मधून Extract करा.
2. GitHub वर sign in करून नवीन repository तयार करा.
3. Extract केलेल्या folder मधील सर्व files आणि folders repository मध्ये upload करा. `.github/workflows/build-apk.yml` देखील upload झाल्याची खात्री करा.
4. Repository मधील Actions tab उघडा. Workflow निवडा आणि **Run workflow** दाबा. Push केल्यावर तो आपोआपही सुरू होऊ शकतो.
5. Workflow run पूर्ण झाल्यावर पानाच्या खाली Artifacts मधून `Smart-Agro-Marketplace-debug-APK` डाउनलोड करा.
6. Artifact ZIP extract करा. `app-debug.apk` वर tap करून install करा. Android विचारल्यास त्या source साठी “Install unknown apps” परवानगी द्या.

## मर्यादा

हा demo/prototype आहे. Products sample data आहेत. वास्तविक accounts/database, payment gateway, escrow, live GPS tracking आणि AI quality model जोडलेले नाहीत. हा debug APK आहे; Play Store release साठी स्वतंत्र signing आणि सुरक्षा तपासणी आवश्यक आहे.
